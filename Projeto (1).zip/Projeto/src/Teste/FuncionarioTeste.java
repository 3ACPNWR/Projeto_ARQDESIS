package Teste;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
public class FuncionarioTeste 
{
	Funcionario funcionario;
		
		@Before
		public void setUp() throws Exception 
		{
			funcionario = new Funcionario();
		}
		
		@Test
		public void testEquals()
		{
			assertEquals("funcionario, new Funcionario("1","Joao",1.200));
		}
		
	}
}
