package Teste;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

import org.junit.Before;
import org.junit.Test;
public class LeitorTeste 
{
	Leitor leitor;
	
	@Before
	public void setUp() throws Exception 
	{
		leitor = new Leitor();
	}
	
	@Test
	public void testEquals()
	{
		assertEquals(File f = new File("projeto/model/texto_decifrado.txt"););
		assertEquals(BufferedReader in = new BufferedReader(new FileReader(caminho));
	}
	
	
}//fim da classe
