package Teste;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
public class ClienteTeste 
{
	Cliente cliente;
	
	@Before
	public void setUp() throws Exception 
	{
		cliente = new Cliente(String cp, String nm, String ag, String ct, int cd, String sn);
	}
	
	@Test
	public void testEquals()
	{
		assertEquals("cliente, new Cliente(42573111857,"Joao",11,3,123456));
	}
	
}
