package Teste;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
public class ImpressoraTeste 
{
	Impressora impressora;
		
		@Before
		public void setUp() throws Exception 
		{
			impressora = new Impressora();
		}
		
	}
}