package Teste;

import static org.junit.Assert.*;

import java.io.File;
import java.util.Formatter;

import org.junit.Before;
import org.junit.Test;
public class criaTxtTeste
{
	criaTxt txt;
			
	@Before
	public void setUp() throws Exception 
	{
		txt = new criaTxt();
	}
			
	@Test
	public void testEquals()
	{
		assertEquals(File f = new File("projeto/model/texto_cifrado.txt"));
		assertEquals(Formatter saida = new Formatter(caminho));
	}
	
}
