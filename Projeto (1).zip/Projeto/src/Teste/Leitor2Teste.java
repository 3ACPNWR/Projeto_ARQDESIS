package Teste;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

import org.junit.Before;
import org.junit.Test;
public class LeitorTeste 
{
	Leitor2 leitor;
	
	@Before
	public void setUp() throws Exception 
	{
		leitor = new Leitor2();
	}
	
	@Test
	public void testEquals()
	{
		assertEquals(BufferedReader in = new BufferedReader(new FileReader("texto_cifrado.txt")));
	}
	
	
}//fim da classe